const express = require('express');
const bodyParser = require('express').json;
const { sequelize } = require('./models');
const customerRoutes = require('./routes/customerRoutes');
const reservationRoutes = require('./routes/reservationRoutes');

const app = express();
app.use(bodyParser());

// Регистрируем маршруты
app.use('/api/customers', customerRoutes);
app.use('/api/reservations', reservationRoutes);

// Точка проверки подключения и синхронизации базы данных
sequelize.authenticate()
  .then(() => console.log('Соединение с базой данных установлено успешно!'))
  .catch(err => console.error('Ошибка подключения:', err));

// Синхронизация (создание таблиц, если их ещё нет) и запуск сервера
const PORT = process.env.PORT || 3000;
sequelize.sync({ force: false /* force: true удаляет и пересоздаёт таблицы */ })
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Сервер запущен на порту ${PORT}`);
    });
  });

module.exports = app; // Экспорт для тестирования при необходимости