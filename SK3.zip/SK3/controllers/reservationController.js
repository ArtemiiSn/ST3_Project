const { Reservation, Customer } = require('../models');

exports.getAllReservations = async (req, res) => {
  try {
    const reservations = await Reservation.findAll({
      include: [{ model: Customer, as: 'customer' }]
    });
    res.json(reservations);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getReservationById = async (req, res) => {
  try {
    const reservation = await Reservation.findByPk(req.params.id, {
      include: [{ model: Customer, as: 'customer' }]
    });
    if (!reservation) {
      return res.status(404).json({ message: "Резервация не найдена" });
    }
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createReservation = async (req, res) => {
  try {
    const { customerId } = req.body;
    // Проверяем, существует ли клиент с указанным идентификатором
    const customer = await Customer.findByPk(customerId);
    if (!customer) {
      return res.status(400).json({ message: "Некорректный customerId" });
    }
    const newReservation = await Reservation.create(req.body);
    res.status(201).json(newReservation);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateReservation = async (req, res) => {
  try {
    const reservation = await Reservation.findByPk(req.params.id);
    if (!reservation) {
      return res.status(404).json({ message: "Резервация не найдена" });
    }
    await reservation.update(req.body);
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteReservation = async (req, res) => {
  try {
    const reservation = await Reservation.findByPk(req.params.id);
    if (!reservation) {
      return res.status(404).json({ message: "Резервация не найдена" });
    }
    await reservation.destroy();
    res.json({ message: "Резервация удалена" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
