const request = require('supertest'); // позволяет имитировать HTTP-запросы к серверу
const app = require('../app');          // наш экземпляр Express-приложения
const { sequelize, Customer } = require('../models');

beforeAll(async () => {
  // Пересоздаём все таблицы перед запуском тестов (чтобы база была чистой)
  await sequelize.sync({ force: true });
});

afterAll(async () => {
  // Закрываем соединение с базой после всех тестов
  await sequelize.close();
});

describe("Тестирование API клиентов", () => {

  it("POST /api/customers – должен создать нового клиента", async () => {
    const newCustomer = {
      name: "Иван Петров",
      email: "ivan@example.com"
    };

    const response = await request(app)
      .post('/api/customers')
      .send(newCustomer)
      .expect(201); // Ожидаем статус 201 – создано

    // Проверяем, что сервер вернул ожидаемые данные
    expect(response.body).toHaveProperty("id");
    expect(response.body.name).toBe(newCustomer.name);
    expect(response.body.email).toBe(newCustomer.email);
  });

  it("GET /api/customers – должен вернуть список клиентов", async () => {
    const response = await request(app)
      .get('/api/customers')
      .expect(200); // Ожидаем статус 200 OK

    // Ответ должен быть массивом
    expect(Array.isArray(response.body)).toBeTruthy();
    // В нашем случае, после предыдущего теста должен присутствовать хотя бы один клиент
    expect(response.body.length).toBeGreaterThan(0);
  });

  it("GET /api/customers/:id – получение конкретного клиента", async () => {
    // Сначала создадим клиента, чтобы знать его ID
    const newCustomer = await Customer.create({
      name: "Мария Иванова",
      email: "maria@example.com"
    });

    const response = await request(app)
      .get(`/api/customers/${newCustomer.id}`)
      .expect(200);

    expect(response.body.id).toBe(newCustomer.id);
    expect(response.body.name).toBe(newCustomer.name);
    expect(response.body.email).toBe(newCustomer.email);
  });

  it("GET /api/customers/:id – должен вернуть 404 при несуществующем клиенте", async () => {
    const response = await request(app)
      .get('/api/customers/9999') // предполагается, что такого ID нет
      .expect(404);

    expect(response.body).toHaveProperty("message", "Клиент не найден");
  });
});
