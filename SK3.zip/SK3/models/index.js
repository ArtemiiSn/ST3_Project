const { Sequelize } = require('sequelize');

// Настроим подключение к PostgreSQL
const sequelize = new Sequelize('hotel_db', 'postgres', '1234', {
  host: 'localhost',
  dialect: 'postgres',
  logging: false, // опционально: отключаем логирование SQL-запросов для чистоты консоли
});

// Импорт моделей
const Customer = require('./customer')(sequelize);
const Reservation = require('./reservation')(sequelize);

// Установка отношений: у каждого клиента может быть много резерваций
Customer.hasMany(Reservation, { as: 'reservations', foreignKey: 'customerId' });
Reservation.belongsTo(Customer, { as: 'customer', foreignKey: 'customerId' });

// Экспортируем объект подключения и модели
module.exports = {
  sequelize,
  Customer,
  Reservation,
};
